#!/usr/bin/env python3
from setuptools import setup

setup(name="demesdraw", use_scm_version={"write_to": "demesdraw/_version.py"})
