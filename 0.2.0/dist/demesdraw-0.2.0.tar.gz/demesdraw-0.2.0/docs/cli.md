
# Command line interface

```{program-output} python -m demesdraw -h
```

## demesdraw tubes

```{program-output} python -m demesdraw tubes -h
```

## demesdraw size_history

```{program-output} python -m demesdraw size_history -h
